import React from "react";
import ReactDOM from "react-dom";
// import pi, { doublePi, triplePi } from "./math.jsx";
import * as pi from "./math.jsx";

ReactDOM.render(
  <ul>
    <li>{pi.default}</li>
    <li>{pi.doublePi()}</li>
    <li>{pi.triplePi()}</li>
  </ul>,
  document.getElementById("root")
);
