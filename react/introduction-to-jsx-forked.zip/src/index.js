import React from "react";
// var React = require("react");
var ReactDOM = require("react-dom");

ReactDOM.render(
  <div>
    <h1>hello world!</h1>
    <p>this is a paragraph</p>
  </div>,
  document.getElementById("root")
);
