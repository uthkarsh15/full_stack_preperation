import React from "react";
import Title from "./Title.jsx";
import List from "./List.jsx";

function App() {
  return (
    <div>
      <Title />
      <List />
    </div>
  );
}

export default App;
