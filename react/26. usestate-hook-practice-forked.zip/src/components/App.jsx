import React, { useState } from "react";

// function getTime() {
//   let time = new Date().toLocaleTimeString();
//   console.log(time);
// }

function App() {
  setInterval(getTime, 1000);
  const now = new Date().toLocaleTimeString();
  const [time, contTime] = useState(now);

  function getTime() {
    const newTime = new Date().toLocaleTimeString();
    contTime(newTime);
  }

  return (
    <div className="container">
      <h1>{time}</h1>
      <button onClick={getTime}>Get Time</button>
    </div>
  );
}

export default App;
