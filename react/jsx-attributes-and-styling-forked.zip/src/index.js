import React from "react";
import ReactDOM from "react-dom";

const img = "https://picsum.photos/200";

ReactDOM.render(
  <div>
    <h1 className="heading" contentEditable="true" spellcheck="false">
      My Favourite Foods
    </h1>
    <div>
      <img src="https://upload.wikimedia.org/wikipedia/en/thumb/5/56/Real_Madrid_CF.svg/500px-Real_Madrid_CF.svg.png" />
      <img src="https://www.motaauto.com/wp-content/uploads/2024/02/Ferrari-Sf-24-F1-2024-6-scaled.jpg" />
      <img src="https://img2.51gt3.com/rac/racer/202404/736683032ce24f06ba67ce44a2cf0b73.jpg" />
      <img src={img + "?grayscale"} />
    </div>
  </div>,
  document.getElementById("root")
);
