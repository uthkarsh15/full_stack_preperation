var numbers = [3, 56, 2, 48, 5];

// function double(x) {
//   return x * 2;
// }
// const newNumber = numbers.map(double);

// var newNumber = [];

// numbers.forEach(function (x) {
//   newNumber.push(x * 2);
// });

// console.log(newNumber);
//Map -Create a new array by doing something with each item in an array.

// const newNumber = numbers.filter(function (nums) {
//   return nums > 10;
// });

// var newNumber = [];
// numbers.forEach(function (nums) {
//   if (nums > 10) {
//     newNumber.push(nums);
//   }
// });
// console.log(newNumber);
//Filter - Create a new array by keeping the items that return true.

// var newNumber = numbers.reduce(function (accumulator, currentNumber) {
//   return accumulator + currentNumber;
// });

// var newNumber = 0;
// numbers.forEach(function (currentNumber) {
//   newNumber += currentNumber;
// });
// console.log(newNumber);
//Reduce - Accumulate a value by doing something to each item in an array.

// const newNumber = numbers.find(function (num) {
//   return num >1;
// });
// console.log(newNumber);
//Find - find the first item that matches from an array.

// const newNumber = numbers.findIndex(function (num) {
//   return num > 10;
// });
// console.log(newNumber);
//FindIndex - find the index of the first item that matches.

import emojipedia from "./emojipedia";

const newEmojiPedia = emojipedia.map(function (emojiEntry) {
  return emojiEntry.meaning.substring(0, 100);
});

console.log(newEmojiPedia);
